package com.example.demo.repository;

import com.example.demo.model.Chofer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ChoferRepository extends JpaRepository<Chofer, Integer> {
}
